# Ana Clara — Site Pessoal (UX + Web Analytics)

Site pessoal de uma página para Ana Clara, estudante de Ciência de Dados e Inteligência Artificial. Além de apresentação pessoal, o projeto foi estruturado como um pequeno estudo de UX + Web Analytics: cada interação relevante (cliques em CTAs, redes sociais, cards de projetos, profundidade de rolagem, visibilidade de seções) já está instrumentada para o Google Analytics 4.

## Tecnologias

- HTML5 semântico, CSS3 e JavaScript puro (sem framework/build step) — carregamento rápido e fácil de hospedar.
- Imagens geradas e otimizadas em WebP/PNG, com favicon e imagem Open Graph próprios.
- Netlify (`netlify.toml`) com cabeçalhos de cache e segurança prontos para deploy.

## Como rodar localmente

Não há processo de build. Basta abrir `index.html` num navegador ou servir a pasta com qualquer servidor estático, por exemplo:

```bash
npx serve .
```

## Ativando o Google Analytics 4

Abra `js/analytics.js` e preencha a constante `GA_MEASUREMENT_ID` com o ID real (formato `G-XXXXXXXXXX`). Enquanto ela estiver vazia, nenhum script do Google é carregado — o site funciona normalmente, sem qualquer coleta.

## O que falta / próximos passos

Ver `PLAN.md` para o roteiro completo (links reais de LinkedIn/GitHub, projetos individuais, decisão sobre uso de fotos pessoais, ativação do GA4).

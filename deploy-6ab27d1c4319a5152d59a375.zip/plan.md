# PLAN.md — Roteiro do site da Ana Clara

## Concluído

1. **Estrutura, UX e identidade visual** — site de uma página reconstruído em HTML semântico, preservando conteúdo e cores da referência original (magenta, verde-limão, creme), com hierarquia visual clara, navegação sticky com menu mobile, CTAs consistentes e feedback visual em botões/cards.
2. **Acessibilidade e contraste** — skip link, foco visível, contraste de texto revisado e corrigido (tom `--pink-text` mais escuro para texto sobre fundo claro), `prefers-reduced-motion` respeitado.
3. **Performance e assets** — imagens em WebP otimizado, favicon (SVG + ICO + apple-touch-icon), imagem Open Graph própria, sem frameworks/dependências de build.
4. **SEO básico** — title, meta description, Open Graph, Twitter Card, headings semânticos, alt text, `netlify.toml` com cabeçalhos de cache e segurança.
5. **Instrumentação GA4** — `js/analytics.js` e `js/main.js` já disparam `link_click`, `project_click`, `cta_click`, `section_view` e `scroll_depth` (25/50/75/90%), sem nenhum ID fictício de GA4 no código.

## Pendente

1. **Links reais de contato** — inserir as URLs verdadeiras do LinkedIn e do GitHub em `index.html` (atualmente `href="#"` como placeholder, já com tracking funcionando).
2. **Projetos individuais** — se a Ana Clara quiser ir além das 3 categorias genéricas (Hackathons, UX/UI, Palestras), fornecer nome, descrição e link de cada projeto para criar cards individuais com evento `project_click` por projeto específico.
3. **Decisão sobre fotos pessoais** — confirmar se as fotos reais da referência enviada devem substituir os elementos gráficos abstratos atuais (`hero-blob.webp`/`footer-blob.webp`).
4. **Ativação do GA4** — inserir o Measurement ID real em `js/analytics.js` (`GA_MEASUREMENT_ID`) quando a propriedade GA4 for criada.
5. **Dashboard de análise de comportamento** — depois que o GA4 estiver coletando dados reais, montar um painel (Looker Studio ou relatórios GA4) para responder às perguntas de UX levantadas (projeto mais clicado, funil até "projetos"/"contato", CTA com mais interação, dispositivo, origem do tráfego).

# AGENTS.md

## Arquitetura

Site estático de uma página, sem framework e sem build step:

- `index.html` — estrutura semântica única (header, hero, sobre, jornada, projetos, fechamento, footer/contato). Todas as seções têm `data-section` para o tracking de visibilidade.
- `css/styles.css` — todo o estilo, com variáveis de cor no `:root`. `--pink-text` é uma variante mais escura de `--pink` usada especificamente em texto sobre fundo claro para garantir contraste AA (a `--pink` original é usada em fundos/botões/elementos grandes).
- `js/analytics.js` — camada de instrumentação GA4. Contém a única constante que a proprietária do site precisa editar (`GA_MEASUREMENT_ID`). Expõe `window.AnaClaraAnalytics.track(eventName, params)`.
- `js/main.js` — interações de UI (menu mobile, barra de progresso de scroll, IntersectionObserver por seção, profundidade de rolagem) e é quem efetivamente chama `AnaClaraAnalytics.track(...)` em cada evento.
- `images/` — assets otimizados: `hero-blob.webp` e `footer-blob.webp` (gerados via IA, substituindo fotos pessoais até haver decisão sobre uso de fotos reais), `favicon.svg`/`favicon.ico`/`apple-touch-icon.png`, `og-image.png`.
- `netlify.toml` — publica a raiz do projeto, define cache longo para `images/css/js` e cabeçalhos de segurança básicos.

## Convenções

- Sem dependências externas de runtime — tudo é HTML/CSS/JS vanilla, propositalmente, para manter o carregamento rápido.
- Todo elemento clicável relevante para métricas usa `data-cta`, `data-link-type` ou `data-project` — `js/main.js` lê esses atributos genericamente, então novos CTAs só precisam do atributo certo, sem editar JS.
- Não inserir nenhum ID de GA4 de exemplo/fictício no código-fonte — a constante em `analytics.js` deve permanecer vazia até a proprietária inserir o ID real.
- Não inventar conteúdo (experiências, empresas, cursos, links) que não veio da própria Ana Clara.

## Decisões não óbvias

- Os botões de LinkedIn e GitHub no rodapé usam `href="#"` como placeholder porque as URLs reais dos perfis não foram fornecidas. `js/main.js` intercepta o clique nesses placeholders (via `data-link-type` + `href === "#"`) para não rolar a página para o topo, e ainda assim dispara o evento `link_click` normalmente.
- A seção de projetos manteve as 3 categorias genéricas vistas na referência original (Hackathons, Projetos de UX/UI, Palestras) como cards clicáveis que alternam um estado "interesse registrado" — isso permite medir engajamento por área mesmo sem projetos individuais com link ainda cadastrados.
- Fotos pessoais da referência original não foram usadas nesta versão; no lugar, dois elementos gráficos abstratos (blobs holográficos gerados via IA Gateway/Gemini) preservam a estética "líquida/holográfica" do design original sem depender de fotos ainda não confirmadas.

Para saber o que falta implementar, ver `PLAN.md`.

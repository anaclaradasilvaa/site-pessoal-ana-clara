/**
 * analytics.js — camada de instrumentação GA4 para o site da Ana Clara.
 *
 * COMO ATIVAR:
 *   1. Crie uma propriedade GA4 em analytics.google.com e copie o "Measurement ID"
 *      (formato "G-XXXXXXXXXX").
 *   2. Cole o ID na constante GA_MEASUREMENT_ID abaixo.
 *   3. Publique o site. Nada mais precisa mudar — todos os eventos abaixo já
 *      estão conectados na interface (js/main.js) e serão enviados automaticamente.
 *
 * Enquanto GA_MEASUREMENT_ID estiver vazio, o gtag.js NUNCA é carregado:
 * não há requisição de rede, não há cookie, não há coleta. O site funciona
 * normalmente e os eventos apenas são descartados (log opcional no console
 * em ambiente local, veja DEBUG abaixo).
 */

(function () {
  "use strict";

  // ---------------------------------------------------------------------
  // 1) Configuração — o único ponto que a Ana Clara precisa editar.
  // ---------------------------------------------------------------------
  var GA_MEASUREMENT_ID = ""; // <- cole aqui o ID real, ex.: "G-XXXXXXXXXX"

  // Ativa logs no console (apenas localhost) para depurar os eventos
  // enquanto o ID real ainda não foi configurado.
  var DEBUG = /^(localhost|127\.0\.0\.1)$/.test(window.location.hostname);

  // ---------------------------------------------------------------------
  // 2) Bootstrap padrão do gtag.js — só carrega o script remoto do Google
  //    se um ID real tiver sido configurado.
  // ---------------------------------------------------------------------
  window.dataLayer = window.dataLayer || [];

  function gtag() {
    window.dataLayer.push(arguments);
  }
  window.gtag = window.gtag || gtag;

  if (GA_MEASUREMENT_ID) {
    var script = document.createElement("script");
    script.async = true;
    script.src = "https://www.googletagmanager.com/gtag/js?id=" + GA_MEASUREMENT_ID;
    document.head.appendChild(script);

    gtag("js", new Date());
    gtag("config", GA_MEASUREMENT_ID, {
      // Mede rolagem em % — combinado com o scroll tracking manual abaixo
      // para ter granularidade em 90% especificamente.
      send_page_view: true,
    });
  }

  // ---------------------------------------------------------------------
  // 3) Função central de tracking usada em todo o site (js/main.js).
  //    Sempre populamos o dataLayer, mesmo sem GA configurado, para que
  //    seja simples plugar outra ferramenta (GTM, Plausible, etc.) depois.
  // ---------------------------------------------------------------------
  function trackEvent(eventName, params) {
    params = params || {};

    if (window.gtag) {
      window.gtag("event", eventName, params);
    }

    if (DEBUG) {
      console.info("[analytics]", eventName, params);
    }
  }

  window.AnaClaraAnalytics = {
    track: trackEvent,
    isConfigured: Boolean(GA_MEASUREMENT_ID),
  };
})();

/**
 * MAPA DE EVENTOS PREPARADOS (ver js/main.js para a implementação):
 *
 *  - link_click        { link_type: "linkedin" | "github" | "email" }
 *      -> Responde: de onde vêm os cliques para cada rede/contato.
 *
 *  - project_click      { project_name: "Hackathons" | "Projetos de UX/UI" | "Palestras" }
 *      -> Responde: qual "projeto"/área recebe mais cliques.
 *
 *  - cta_click          { cta_name, cta_location }
 *      -> Responde: qual CTA recebe mais interações.
 *
 *  - section_view       { section_id, section_name }
 *      -> Disparado uma vez por seção, via IntersectionObserver.
 *      -> Responde: as pessoas chegam até "projetos"? Chegam ao rodapé/contato?
 *
 *  - scroll_depth       { percent: 25 | 50 | 75 | 90 }
 *      -> Responde: quanto da página é efetivamente lida/rolada.
 *
 *  - nav_click          { nav_label }
 *      -> Uso do menu de navegação (topo e mobile).
 *
 * Perguntas de UX que esses eventos permitem responder (combinados com os
 * relatórios padrão do GA4 — Aquisição e Tecnologia, que já vêm de fábrica):
 *   - Qual projeto recebe mais cliques?           -> project_click
 *   - As pessoas chegam até a seção de projetos?  -> section_view (projetos)
 *   - As pessoas chegam ao final da página?       -> section_view (contato) + scroll_depth 90
 *   - Qual CTA recebe mais interações?             -> cta_click
 *   - Mobile ou desktop?                            -> relatório GA4 "Tecnologia > Visão geral"
 *   - De onde vêm os visitantes?                    -> relatório GA4 "Aquisição de tráfego"
 *   - Quais partes despertam mais interesse?        -> section_view + tempo entre eventos
 */

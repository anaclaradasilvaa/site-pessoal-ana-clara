/**
 * main.js — interações de UI e disparo dos eventos GA4 definidos em analytics.js
 */
(function () {
  "use strict";

  var track = function (name, params) {
    if (window.AnaClaraAnalytics) {
      window.AnaClaraAnalytics.track(name, params);
    }
  };

  document.addEventListener("DOMContentLoaded", function () {
    // Ano dinâmico no rodapé -------------------------------------------
    var yearEl = document.getElementById("year");
    if (yearEl) yearEl.textContent = new Date().getFullYear();

    // Menu mobile ---------------------------------------------------------
    var toggle = document.querySelector(".nav__toggle");
    var mobileMenu = document.getElementById("nav-mobile");
    if (toggle && mobileMenu) {
      toggle.addEventListener("click", function () {
        var isOpen = toggle.getAttribute("aria-expanded") === "true";
        toggle.setAttribute("aria-expanded", String(!isOpen));
        toggle.setAttribute("aria-label", isOpen ? "Abrir menu" : "Fechar menu");
        mobileMenu.hidden = isOpen;
        mobileMenu.classList.toggle("is-open", !isOpen);
      });

      mobileMenu.querySelectorAll("a").forEach(function (link) {
        link.addEventListener("click", function () {
          toggle.setAttribute("aria-expanded", "false");
          toggle.setAttribute("aria-label", "Abrir menu");
          mobileMenu.hidden = true;
          mobileMenu.classList.remove("is-open");
        });
      });
    }

    // Tracking genérico de CTAs/links (data-cta) --------------------------
    document.querySelectorAll("[data-cta]").forEach(function (el) {
      el.addEventListener("click", function () {
        track("cta_click", {
          cta_name: el.getAttribute("data-cta"),
          cta_location: el.closest("[data-section]")
            ? el.closest("[data-section]").getAttribute("data-section")
            : "unknown",
        });
      });
    });

    // Tracking específico de links de contato (LinkedIn/GitHub/E-mail) ----
    document.querySelectorAll("[data-link-type]").forEach(function (link) {
      link.addEventListener("click", function (event) {
        var type = link.getAttribute("data-link-type");
        track("link_click", { link_type: type });

        // LinkedIn/GitHub ainda não têm URL real configurada nesta versão.
        // Evita navegar para "#" (o que rolaria a página) até que os links
        // reais sejam preenchidos no HTML.
        if (link.getAttribute("href") === "#") {
          event.preventDefault();
          link.setAttribute("title", "Link a confirmar — adicione a URL real no index.html");
        }
      });
    });

    // Tracking de cliques em "projetos" ------------------------------------
    document.querySelectorAll("[data-project]").forEach(function (card) {
      card.addEventListener("click", function () {
        var name = card.getAttribute("data-project");
        var nowPressed = card.getAttribute("aria-pressed") !== "true";
        card.setAttribute("aria-pressed", String(nowPressed));
        track("project_click", { project_name: name, marked_interesting: nowPressed });
      });
    });

    // Visibilidade de seções (funil de rolagem) ----------------------------
    var seenSections = {};
    var sections = document.querySelectorAll("[data-section]");
    if ("IntersectionObserver" in window && sections.length) {
      var sectionObserver = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            var id = entry.target.getAttribute("data-section");
            if (entry.isIntersecting && !seenSections[id]) {
              seenSections[id] = true;
              track("section_view", { section_id: id });
            }
          });
        },
        { threshold: 0.4 }
      );
      sections.forEach(function (section) {
        sectionObserver.observe(section);
      });
    }

    // Profundidade de rolagem + barra de progresso --------------------------
    var progressBar = document.getElementById("scrollProgressBar");
    var firedDepths = {};
    var depths = [25, 50, 75, 90];

    var onScroll = function () {
      var doc = document.documentElement;
      var scrollTop = doc.scrollTop || document.body.scrollTop;
      var scrollHeight = doc.scrollHeight - doc.clientHeight;
      var percent = scrollHeight > 0 ? (scrollTop / scrollHeight) * 100 : 0;

      if (progressBar) {
        progressBar.style.width = Math.min(percent, 100) + "%";
      }

      depths.forEach(function (depth) {
        if (percent >= depth && !firedDepths[depth]) {
          firedDepths[depth] = true;
          track("scroll_depth", { percent: depth });
        }
      });
    };

    var ticking = false;
    window.addEventListener(
      "scroll",
      function () {
        if (!ticking) {
          window.requestAnimationFrame(function () {
            onScroll();
            ticking = false;
          });
          ticking = true;
        }
      },
      { passive: true }
    );
    onScroll();
  });
})();
